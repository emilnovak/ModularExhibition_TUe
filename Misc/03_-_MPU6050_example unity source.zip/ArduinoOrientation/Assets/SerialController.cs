﻿using UnityEngine;
using System.IO.Ports;
using System;
using System.Threading;
using UnityEngine.UI;

public class SerialController : MonoBehaviour {

	public static SerialController instance;
	public static float x, y, z;
	public static bool sensorConnected = false;

	public string comPort = "COM6";
	public int baudRate = 9600;
	private static volatile string dataMsg;

	public SerialPort port;
	public Thread serialThread;
	public InputField portInput;

	Quaternion to;

	private void Start() {
		if (PlayerPrefs.HasKey("com")) {
			portInput.text = PlayerPrefs.GetString("com");
		}
	}

	void Init () {
		port = new SerialPort(comPort, 9600);
	}

	void ReceiveData() {
		Debug.Log("Serial receiver thread started.");
		while (true) {
			try {
				//Debug.Log(port.ReadChar().ToString());
				dataMsg = port.ReadLine();
				string[] angles = dataMsg.Split(',');
				if(angles.Length == 3) {
					float.TryParse(angles[0], out x);
					float.TryParse(angles[1], out y);
					float.TryParse(angles[2], out z);
				}
			} catch (Exception e) {
				Debug.Log("Thread quit:");
				throw new UnityException(e.ToString());
			}
		}
		
	}

	private void Update() {
		to = Quaternion.Euler(x, y, z);
		transform.localRotation = Quaternion.Lerp(transform.localRotation, to, Time.deltaTime * 16f);
	}

	void OnApplicationQuit() {
		if(serialThread != null) {
			serialThread.Abort();
		}
		if(port != null) {
			port.Close();
		}
	}

	public void SetCom(string value) {
		if(value != "") {
			comPort = value.ToUpper();
			PlayerPrefs.SetString("com", comPort);
		}
	}

	public void Connect() {
		if (PlayerPrefs.HasKey("com")) {
			comPort = PlayerPrefs.GetString("com");
		}
		Init();
		try {
			port.ReadTimeout = 10000;
			port.Handshake = Handshake.None;
			port.Parity = Parity.None;
			port.Encoding = System.Text.Encoding.ASCII;
			port.DtrEnable = true;
			port.Open();
			serialThread = new Thread(ReceiveData);
			serialThread.Start ();
			Debug.Log("Serial port " + comPort + " open. Baudrate: " + baudRate);
		} catch (SystemException e) {
			Debug.Log ("Error opening serial port: " + e.Message);
		}
	
	}

}